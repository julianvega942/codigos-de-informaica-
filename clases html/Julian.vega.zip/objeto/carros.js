let carro1 ={  marca: "hyundai", modelo: "tucson",año: "2022", kilometraje:"0",kgb:"180" }
let carro2= {marca:"chevrolet", modelo: "spark gt", año: "2012", kilometraje:"100", kgb: "110"}
let carro3= {marca:"toyota",modelo:"rush",año:"2022",kilometraje:"0",kgb:"190" }
let carro4={marca:"mercedes benz", modelo:"tourer",año:"2021", kilometraje:"0", kgb:"200"}


let arraycarros= [ carro1,carro2]
let conductor= {nombre:" Juampis G", edad:"70",ciudad:"Israel",vehiculos:arraycarros}